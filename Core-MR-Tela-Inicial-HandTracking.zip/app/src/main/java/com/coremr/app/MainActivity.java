package com.coremr.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult;
import java.util.concurrent.*;

public class MainActivity extends AppCompatActivity {
    private FrameLayout root; private PreviewView preview; private Overlay overlay; private ExecutorService cameraExecutor; private HandLandmarker landmarker;
    private static final int REQ=44;
    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }

    private void showHome(){
        ImageView home=new ImageView(this);
        home.setImageResource(com.coremr.app.R.drawable.core_mr_home);
        home.setScaleType(ImageView.ScaleType.CENTER_CROP);
        home.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_UP){
                float y=e.getY()/Math.max(1f,home.getHeight());
                if(y>0.55f && y<0.80f){ startMR(); return true; }
                if(y>=0.80f){ Toast.makeText(this,"CORE MR • Realidade mista • Hand tracking",Toast.LENGTH_SHORT).show(); return true; }
            }
            return true;
        });
        setContentView(home);
    }
    private void startMR(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},REQ); return; }
        showLoading();
        new Handler().postDelayed(()->openCamera(),900);
    }
    private void showLoading(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setBackgroundColor(Color.BLACK);
        TextView title=new TextView(this); title.setText("CORE MR\n\ncarregando realidade mista..."); title.setTextColor(Color.WHITE); title.setGravity(Gravity.CENTER); title.setTextSize(25); box.addView(title,new LinearLayout.LayoutParams(-1,0,1));
        ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); p.setMax(100); p.setProgress(0); box.addView(p,new LinearLayout.LayoutParams(-1,35));
        TextView n=new TextView(this); n.setText("0 / 100"); n.setTextColor(Color.WHITE); n.setGravity(Gravity.CENTER); n.setTextSize(20); box.addView(n,new LinearLayout.LayoutParams(-1,70)); setContentView(box);
        new Thread(()->{for(int i=0;i<=100;i++){final int x=i; runOnUiThread(()->{p.setProgress(x);n.setText(x+" / 100");}); try{Thread.sleep(12);}catch(Exception ignored){}}}).start();
    }
    private void openCamera(){
        root=new FrameLayout(this); preview=new PreviewView(this); root.addView(preview,new FrameLayout.LayoutParams(-1,-1)); overlay=new Overlay(); root.addView(overlay,new FrameLayout.LayoutParams(-1,-1)); setContentView(root);
        cameraExecutor=Executors.newSingleThreadExecutor(); setupLandmarker();
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this); future.addListener(()->{try{ProcessCameraProvider p=future.get(); Preview pr=new Preview.Builder().build(); pr.setSurfaceProvider(preview.getSurfaceProvider()); ImageAnalysis an=new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).setTargetResolution(new Size(640,480)).build(); an.setAnalyzer(cameraExecutor,this::analyze); p.unbindAll(); p.bindToLifecycle(MainActivity.this,CameraSelector.DEFAULT_FRONT_CAMERA,pr,an);}catch(Exception e){Toast.makeText(this,"Câmera indisponível",Toast.LENGTH_LONG).show();}},ContextCompat.getMainExecutor(this));
    }
    private void setupLandmarker(){ try{ BaseOptions base=BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build(); HandLandmarker.HandLandmarkerOptions opts=HandLandmarker.HandLandmarkerOptions.builder().setBaseOptions(base).setNumHands(2).setMinHandDetectionConfidence(0.55f).setMinHandPresenceConfidence(0.55f).setMinTrackingConfidence(0.55f).build(); landmarker=HandLandmarker.createFromOptions(this,opts);}catch(Exception e){Toast.makeText(this,"Modelo de mão não encontrado. O rastreamento precisa do hand_landmarker.task.",Toast.LENGTH_LONG).show();} }
    private void analyze(ImageProxy image){ if(landmarker==null){image.close();return;} try{ Bitmap bmp=image.toBitmap(); MPImage mp=new BitmapImageBuilder(bmp).build(); HandLandmarkerResult r=landmarker.detect(mp); runOnUiThread(()->overlay.setResult(r)); }catch(Exception ignored){} finally{image.close();} }
    @Override protected void onDestroy(){super.onDestroy();if(cameraExecutor!=null)cameraExecutor.shutdown();if(landmarker!=null)landmarker.close();}
    public class Overlay extends View { Paint line=new Paint(3),dot=new Paint(3); HandLandmarkerResult result; final int[][] EDGES={{0,1},{1,2},{2,3},{3,4},{0,5},{5,6},{6,7},{7,8},{5,9},{9,10},{10,11},{11,12},{9,13},{13,14},{14,15},{15,16},{13,17},{17,18},{18,19},{19,20},{0,17}}; Overlay(){super(MainActivity.this);line.setColor(Color.CYAN);line.setStrokeWidth(6);dot.setColor(Color.WHITE);dot.setStrokeWidth(10);}
        void setResult(HandLandmarkerResult r){result=r;invalidate();}
        protected void onDraw(Canvas c){super.onDraw(c);if(result==null)return;float sx=getWidth()/640f,sy=getHeight()/480f;for(var hand:result.landmarks()){for(int[] e:EDGES){var a=hand.get(e[0]);var b=hand.get(e[1]);c.drawLine(a.x()*getWidth(),a.y()*getHeight(),b.x()*getWidth(),b.y()*getHeight(),line);}for(var p:hand)c.drawCircle(p.x()*getWidth(),p.y()*getHeight(),6,dot);}}
    }
}
